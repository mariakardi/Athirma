package Class_folder;

public class Parents_Group {

    public Parents_Group(){

    }

    public String[] getPG(){
        return null;
    }

    public String[] getMembers(){
        return null;
    }

    public String[] getMeetingLog(){
        return null;
    }

    public boolean deleteMeetingLog(){
        return true;
    }
}