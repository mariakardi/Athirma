package Class_folder;

public class Activities {
    private String quiz_id;
    private String drawing_title;
    private String student_id;
   

    public static boolean createActivities() {
        return true;
    }
    public static String[] getActivities(String quiz_id) {
        return null;
    }
    public static boolean deleteActivities(String quiz_id) {
        return true;
    }
}